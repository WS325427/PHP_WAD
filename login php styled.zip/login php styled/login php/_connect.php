<?php
//include_once("_login_check.php");
$db_server = "plesk.remote.ac";
$db_user = "WS325427_wad";
$db_password="Gf6q74v#";
$db_database = "WS325427_wad";

$db_connect = mysqli_connect($db_server,$db_user,$db_password,$db_database)
?>